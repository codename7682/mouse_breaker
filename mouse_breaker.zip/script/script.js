$(document).ready(function(){
    
    var first = true;
    var num = 0;
    var barw = 0;
    var start;
    var now;
    var dur;
    var limit = 60000;
    
    $("#btn").click(function(){
        if(first){
            first = false;
            $(this).text("클릭!");
            start = new Date();
            start = start.getTime();
        }else{
            num++;
            barw += 3;
            $("#number").text(num);
            $("#bar").width(barw);
        }
    });
    
    function damage(){
        if(barw > 0){
            barw -= 1;
        }else{
            barw = 0;
        }
        $("#bar").width(barw);
        if(num < 50){
            $("#number").css("color","red");
        }else if(num >= 50 && num < 100){
            $("#number").css("color","orange");
        }else if(num >= 100 && num < 150){
            $("#number").css("color","green");
        }else{
            $("#number").css("color","blue");
        }
    }    
    
    var dam = setInterval(damage, 100);
    
    
    
    function timer(){
        now = new Date();
        now = now.getTime();
        dur = now - start;
//        75200ms = 75s 200ms = 1m 15s 200ms;
//                        m 75200/60000
//                        s 15200/1000
//                        ms  200 (/1000*60)
        var min = Math.floor(dur / 60000);
        var sec = Math.floor((dur % 60000)/1000);
        var msec = Math.floor((dur % 1000) / 1000 * 60);
        
        if(dur >= limit){
            clearInterval(time);
            clearInterval(dam);
            $("#btn").attr("disabled","true");
            alert("당신의 점수는 "+num+"점 입니다.");
            var again = confirm("한판 더?");
            if(again){
                location.reload();
            }
        }
        
        if(min < 10){
            min = "0"+min;
        }
        if(sec < 10){
            sec = "0"+sec;
        }
        if(msec < 10){
            msec = "0"+msec;
        }
        
        if(!isNaN(dur)){
            $("#timer").text(min+":"+sec+":"+msec);
        }
    }
    
    var time = setInterval(timer,1);
    
    $(document).keydown(function(){
        alert("키보드 사용은 반칙입니다.");
        location.reload();
    });
    
});




